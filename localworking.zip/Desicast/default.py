#!/usr/bin/python
#
# Written by Ksosez, BlueCop
# Released under GPL(v2)
# Updated for Kodi 22 (Python 3)

import urllib.request
import urllib.parse
import http.cookiejar
import cgi
import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import xbmcvfs
import os
import random
import re
import json
import sys
import time
from datetime import datetime, timedelta

import xml.etree.ElementTree as ET

## Get the settings

selfAddon = xbmcaddon.Addon(id='plugin.video.DesiCast')
translation = selfAddon.getLocalizedString
defaultimage = 'special://home/addons/plugin.video.DesiCast/icon.png'
defaultfanart = 'special://home/addons/plugin.video.DesiCast/fanart.jpg'
defaultlive = 'special://home/addons/plugin.video.DesiCast/resources/media/new_live.png'
defaultreplay = 'special://home/addons/plugin.video.DesiCast/resources/media/new_replay.png'
defaultupcoming = 'special://home/addons/plugin.video.DesiCast/resources/media/new_upcoming.png'

pluginpath = selfAddon.getAddonInfo('path')
pluginhandle = int(sys.argv[1])

# Fixed for Kodi 22 (xbmcvfs replaces xbmc.translatePath)
ADDONDATA = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.DesiCast/')
if not os.path.exists(ADDONDATA):
    os.makedirs(ADDONDATA)
USERFILE = os.path.join(ADDONDATA, 'userdata.xml')

# Fixed for Python 3
cj = http.cookiejar.LWPCookieJar()
networkmap = {'n360': 'ESPN3', 'n44': 'ESPNPASS'}

channels = '&channel='
channels += 'espnpass'


def CATEGORIES():
    url = 'http://specpals.com/xml/categories.xml'
    data = get_html(url)
    if not data:
        return
    i = 0
    for cat in ET.XML(data).findall('category'):
        title = cat.get('title')
        img = cat.get('sd_img')
        addDir(title, url, 2, img, i)
        i = i + 1
    xbmc.executebuiltin('Container.SetViewMode(%d)' % 500)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def LISTNETWORKS(url, name):
    pass


def LISTSPORTS(url, name, catid):
    data = get_html(url)
    if not data:
        return
    i = 0
    for cat in ET.XML(data).findall('category'):
        if i == catid:
            for event in cat.findall('categoryLeaf'):
                image = event.get('sd_img')
                title = event.get('title')  # Removed .encode()
                url = event.get('feed')
                addDir(title, url, 3, image, 0)
        i = i + 1
    xbmc.executebuiltin('Container.SetViewMode(%d)' % 500)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def INDEXBYSPORT(url, name):
    INDEX(url, name, bysport=True)


def INDEX(url, name, bysport=False):
    data = get_html(url)
    if not data:
        return
    list_index = 1
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    total = len(ET.XML(data).findall('item'))
    xbmc.log("Total: " + str(total), xbmc.LOGINFO)
    
    for event in ET.XML(data).findall('item'):
        ename = event.findtext('title')  # Removed .encode()
        authurl = event.findtext('./media/streamUrl')
        thumb = event.get('sdImg')
        
        item = xbmcgui.ListItem(ename)
        
        # Kodi 22 Compliant Info Settings
        video_info = item.getVideoInfoTag()
        video_info.setTitle(ename)
        video_info.setPlot(ename)
        
        item.setProperty('IsPlayable', 'true')
        
        # Kodi 22 Compliant Artwork Settings
        item.setArt({'thumb': thumb, 'icon': thumb})
        
        addLink(ename, authurl, 4, total, thumb, thumb)
       
    xbmcplugin.setContent(pluginhandle, 'episodes')
    xbmc.executebuiltin('Container.SetViewMode(%d)' % 500)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def PLAYESPN3(url):
    PLAY(url, 'n360')


def PLAY(url, videonetwork):
    if 'rtmp:' in url or 'rtmpe:' in url:
        url = url.replace("circhd_token", "")
    elif 'neotv' in url:
        var = urllib.request.urlopen(url)
        saveUserdata2(url)
        xbmc.log('GET URl:' + url, xbmc.LOGINFO)
        data = ReadFile('userdata2.txt', ADDONDATA)
        url_match = re.compile('"liveStream":"(.+?)"}').findall(data)
        url = url_match[0]  
        xbmc.log('Neo TV:  url: ' + url, xbmc.LOGINFO)	
    elif 'specpals' in url:
        var = urllib.request.urlopen(url)
        url = var.geturl()
        xbmc.log('PLAY URl:' + url, xbmc.LOGINFO)
    else:  	
        url = url + "|User-Agent=Mozilla/5.0 (CrKey armv7l 1.4.15250) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.0 Safari/537.36"
    
    item = xbmcgui.ListItem(path=url)
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def getJSON(url):
    response = urllib.request.urlopen(url)
    data = json.load(response)
    url = data["results"]["liveStream"]
    xbmc.log('GET JSON URl:' + url, xbmc.LOGINFO)	
    
	
def saveUserdata2(url):
    data1 = get_html(url)
    SaveFile('userdata2.txt', data1, ADDONDATA)
    
	
def saveUserdata():
    checkrights = 'http://broadband.espn.go.com/espn3/auth/espnnetworks/user'


def get_html(url):
    try:
        xbmc.log('ESPN3:  get_html: ' + url, xbmc.LOGINFO)
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
        opener.addheaders = [('User-Agent', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.2.17) Gecko/20110422 Ubuntu/10.10 (maverick) Firefox/3.6.17')]
        usock = opener.open(url)
        response = usock.read()
        usock.close()
        # Decode bytes to string for Python 3
        return response.decode('utf-8', errors='ignore')
    except Exception as e: 
        xbmc.log('Error fetching HTML: ' + str(e), xbmc.LOGERROR)
        return False


def get_params():
    param = {}
    if len(sys.argv) >= 3:
        paramstring = sys.argv[2]
        if len(paramstring) >= 2:
            cleanedparams = paramstring.replace('?', '')
            if cleanedparams.endswith('/'):
                cleanedparams = cleanedparams[:-1]
            pairsofparams = cleanedparams.split('&')
            for pair in pairsofparams:
                splitparams = pair.split('=')
                if len(splitparams) == 2:
                    param[splitparams[0]] = splitparams[1]
    return param


def SaveFile(filename, data, directory):
    path = os.path.join(directory, filename)
    mode = 'w' if os.path.exists(path) else 'w+'
    with open(path, mode, encoding='utf-8') as f:
        f.write(data)


def ReadFile(filename, directory):
    path = os.path.join(directory, filename)
    if filename == 'userdata.htm':
        if not os.path.exists(path):
            saveUserdata()
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()


def addLink(name, url, mode, total, iconimage, fanart=False):
    u = sys.argv[0] + "?url=" + urllib.parse.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.parse.quote_plus(name)
    liz = xbmcgui.ListItem(name)
    
    video_info = liz.getVideoInfoTag()
    video_info.setTitle(name)
    
    liz.setProperty('IsPlayable', 'true')
    if not fanart:
        fanart = defaultfanart
        
    liz.setArt({'thumb': iconimage, 'icon': "DefaultVideo.png", 'fanart': fanart})
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, totalItems=total)


def addDir(name, url, mode, iconimage, catid, fanart=False):
    u = sys.argv[0] + "?url=" + urllib.parse.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.parse.quote_plus(name) + "&catid=" + str(catid)
    liz = xbmcgui.ListItem(name)
    
    video_info = liz.getVideoInfoTag()
    video_info.setTitle(name)
    
    if not fanart:
        fanart = defaultfanart
        
    liz.setArt({'thumb': iconimage, 'icon': "DefaultFolder.png", 'fanart': fanart})
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)

# Main execution safety check (Prevents crash if final parameters are clipped)
params = get_params()
url = params.get('url')
name = params.get('name')
mode = params.get('mode')
catid = params.get('catid')

if url:
    url = urllib.parse.unquote_plus(url)
if name:
    name = urllib.parse.unquote_plus(name)
if mode:
    mode = int(mode)
if catid:
    catid = int(catid)

# Router block (Example setup based on script modes)
if mode is None or url is None or len(url) < 1:
    CATEGORIES()
elif mode == 2:
    LISTSPORTS(url, name, catid)
elif mode == 3:
    INDEX(url, name)
elif mode == 4:
    PLAY(url, 'n360')
